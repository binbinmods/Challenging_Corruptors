# 1.2.2

Changed default to All Extreme rather than Winds of Amnesia.

# 1.2.1

Updated Upwind to be an Extreme corruptor if All Extreme is chosen.

# 1.2.0

Added Upwind option

# 1.1.0

Added Winds of Amnesia option

# 1.0.0

Initial release.
