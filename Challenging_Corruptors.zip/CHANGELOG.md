# 1.2.0

Added Upwind option

# 1.1.0

Added Winds of Amnesia option

# 1.0.0

Initial release.
