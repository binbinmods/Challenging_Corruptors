# Challenging Corruptors

Sick of getting Easy corruptors? Want a challenge? Challenging Corruptors allows you to choose the minimum difficulty of your corruptors.

Defaults to only Hard and Extreme corruptors; after first run a config file is created in your BepInEx _config_ folder that allows you to change the minimum corruptor difficulty.

## Installation

Install [BepInEx](https://across-the-obelisk.thunderstore.io/package/BepInEx/BepInExPack_AcrossTheObelisk/).

Download the [latest release](https://github.com/stiffmeds/Challenging_Corruptors/releases/latest) and put it in your BepInEx _plugins_ folder.

## Support

Raise a Github issue or ping @stiffmeds in the #modding channel of the [official Across the Obelisk Discord](https://discord.gg/across-the-obelisk-679706811108163701).

## Donations

I make mods because I love it, not because I want to make money from it. If you really, really want to donate to me, my preferred non-profit organisations are [Greyhound Adoptions WA](https://greyhoundadoptionswa.com.au/donation/) ([paypal](https://www.paypal.com/donate?token=m8DwEGGEH0FFsS6PS-5p4MX9_5g8_ocMMrNFjaELN-xcG6Ok-KCFabu5xtB-57QBiOM7QLSuKVUepvL_)) or [Headache Australia](https://headacheaustralia.org.au/donate/).